#include "chromeboy_engine.h"
#include <math.h>

ChromeBoyProject g_chromeboy;

void init_dsp() {
    g_chromeboy.bpm = 120.0f;
    g_chromeboy.swing = 0.30f;
    g_chromeboy.is_playing = false;
    g_chromeboy.active_track = 0;
    g_chromeboy.page_2_active = false;
    for(int i=0; i<NUM_TRACKS; i++) {
        g_chromeboy.tracks[i].vol = 0.8f;
        g_chromeboy.tracks[i].pan = 0.0f;
        g_chromeboy.tracks[i].muted = false;
        g_chromeboy.tracks[i].p1 = 0.5f;
        g_chromeboy.tracks[i].p2 = 0.5f;
        g_chromeboy.tracks[i].p3 = 0.5f;
        g_chromeboy.tracks[i].p4 = 0.5f;
    }
}

// Processing block hook mapping to the libfm1_engine.a audio callback
void process_audio_block(float* out_l, float* out_r, int num_frames) {
    for(int i = 0; i < num_frames; i++) {
        float mix_l = 0.0f;
        float mix_r = 0.0f;
        
        // 10-Track Mixer Loop
        for(int t=0; t<NUM_TRACKS; t++) {
            if(g_chromeboy.tracks[t].muted) continue;
            
            float sample = 0.0f; // FM-1 HW synth voices run here
            
            float pan = g_chromeboy.tracks[t].pan;
            float pan_l = cosf((pan + 1.0f) * 0.25f * M_PI);
            float pan_r = sinf((pan + 1.0f) * 0.25f * M_PI);
            
            mix_l += sample * g_chromeboy.tracks[t].vol * pan_l;
            mix_r += sample * g_chromeboy.tracks[t].vol * pan_r;
        }
        
        out_l[i] = mix_l;
        out_r[i] = mix_r;
    }
}
