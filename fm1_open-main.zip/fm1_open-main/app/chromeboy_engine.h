#pragma once
#include <stdint.h>
#include <stdbool.h>

#define NUM_TRACKS 10
#define NUM_STEPS 32
#define SAMPLE_RATE 44100

enum EngineType {
    ENGINE_KICK,
    ENGINE_SNARE,
    ENGINE_HAT,
    ENGINE_PERC,
    ENGINE_STAB,
    ENGINE_PIANO,
    ENGINE_ACID,
    ENGINE_BASS
};

struct Step {
    bool active;
    bool slide;
    uint8_t ratchet;
    uint8_t note;
};

struct Track {
    EngineType engine;
    Step steps[NUM_STEPS];
    float vol;
    float pan;
    bool muted;
    
    // Macro params mapped to K1-K4
    float p1, p2, p3, p4; 
};

struct ChromeBoyProject {
    Track tracks[NUM_TRACKS];
    float bpm;
    float swing;
    uint8_t active_track;
    uint8_t current_step;
    bool is_playing;
    bool page_2_active;
};

extern ChromeBoyProject g_chromeboy;

void init_dsp();
void process_audio_block(float* out_l, float* out_r, int num_frames);
void render_ui();
void trigger_step(int track_idx, int step_idx);
