#pragma once
#include "chromeboy_engine.h"
#include <stdlib.h>

static inline void apply_track_generator(ChromeBoyProject* proj, uint8_t track_idx) {
    Track* t = &proj->tracks[track_idx];
    for (int i = 0; i < 32; i++) {
        t->steps[i].active = false;
        t->steps[i].slide = false;
        t->steps[i].ratchet = 1;
    }
    switch (track_idx) {
        case 0: // GEN 4/4 KICK
            for (int i = 0; i < 32; i += 4) t->steps[i].active = true;
            break;
        case 1: // GEN SNARE & CLAPS
            for (int i = 4; i < 32; i += 8) t->steps[i].active = true;
            t->steps[14].active = true;
            t->steps[30].active = true;
            break;
        case 2: // GEN 909 CLOSED HATS
            for (int i = 0; i < 32; i++) {
                if (i % 4 != 2) {
                    t->steps[i].active = (rand() % 100) > 20;
                    if ((i % 8 == 7) && ((rand() % 100) > 50)) t->steps[i].ratchet = 2;
                }
            }
            break;
        case 3: // GEN OPEN HATS
            for (int i = 2; i < 32; i += 4) t->steps[i].active = true;
            break;
        case 4: // GEN SYNC COWBELL
            {
                static const uint8_t cow_hits[] = { 4, 7, 11, 12, 14, 20, 23, 27, 28, 30 };
                for (int i = 0; i < 10; i++) t->steps[cow_hits[i]].active = true;
                t->steps[14].ratchet = 2; t->steps[30].ratchet = 2;
            }
            break;
        case 6: // GEN 90S STABS
        case 7: // GEN JV PIANO
            {
                static const uint8_t chord_hits[] = { 0, 3, 8, 10, 16, 19, 24, 26 };
                uint8_t rand_profile = rand() % 9;
                for (int i = 0; i < 8; i++) {
                    t->steps[chord_hits[i]].active = true;
                    t->steps[chord_hits[i]].note = rand_profile;
                }
            }
            break;
        case 8: // RANDOM ACID 303 ARP
            {
                static const uint8_t scale[] = { 36, 39, 41, 43, 46, 48, 51, 53, 55 };
                for (int i = 0; i < 32; i++) {
                    if ((rand() % 100) > 35) {
                        t->steps[i].active = true;
                        t->steps[i].note = scale[rand() % 9];
                        t->steps[i].slide = (rand() % 100) > 60;
                    }
                }
            }
            break;
        case 9: // GEN MOTIF BASSLINE
            {
                static const uint8_t bass_hits[] = { 2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31 };
                for (int i = 0; i < 16; i++) {
                    t->steps[bass_hits[i]].active = true;
                    t->steps[bass_hits[i]].note = (i % 4 == 2) ? 34 : ((i % 4 == 3) ? 31 : 29);
                }
            }
            break;
    }
}
