#include "chromeboy_engine.h"
#include "cold_chrome_logo.h"

extern uint16_t display_fb[160 * 128];
extern void lcd_refresh();
extern void delay_ms(int ms);

#define DMG_BG_GREEN    0x8D65
#define DMG_DK_ACCENT   0x3306
#define DMG_INK_BLACK   0x09C2

void draw_pixel(int x, int y, uint16_t color) {
    if(x >= 0 && x < 160 && y >= 0 && y < 128) {
        display_fb[y * 160 + x] = color;
    }
}

void draw_rect(int x, int y, int w, int h, uint16_t color) {
    for(int i=0; i<w; i++) {
        for(int j=0; j<h; j++) {
            draw_pixel(x+i, y+j, color);
        }
    }
}

void show_boot_screen() {
    draw_rect(0, 0, 160, 128, DMG_BG_GREEN);
    
    // Draw 96x96 Logo Centered (X: 32, Y: 10)
    for(int row=0; row<96; row++) {
        for(int col=0; col<96; col++) {
            int byte_idx = (row * 12) + (col / 8);
            if(cold_chrome_logo_bits[byte_idx] & (0x80 >> (col % 8))) {
                draw_pixel(32 + col, 10 + row, DMG_INK_BLACK);
            }
        }
    }
    
    // Mock string rendering
    // lcd_draw_string(18, 108, "CHROME BOY FM", 0x09C2);
    // lcd_draw_string(14, 118, "COLD CHROME REC", 0x3306);
    
    lcd_refresh();
    delay_ms(2500); 
}

void render_ui() {
    draw_rect(0, 0, 160, 128, DMG_BG_GREEN);
    // Draw sequencer logic and parameter mapping...
    lcd_refresh();
}
